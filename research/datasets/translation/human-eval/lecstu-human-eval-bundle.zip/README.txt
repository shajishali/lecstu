LECSTU Translation Human Evaluation (Phase 9.4)
Packaged: 2026-07-07

1. Read INSTRUCTIONS.md
2. Open human_eval_form.csv to see each sentence + translation
3. Copy rater_template.csv to ratings_YOURNAME.csv
4. Fill fluency, adequacy, overall (1-5) for every item_id
5. Email/send ratings_YOURNAME.csv back to the researcher

Do not share ratings with other evaluators before submitting.
